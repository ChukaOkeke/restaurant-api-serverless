def handler(event, context):
    return {'statusCode': 200, 'body': 'Asgard Lambda Engine Initialized'}